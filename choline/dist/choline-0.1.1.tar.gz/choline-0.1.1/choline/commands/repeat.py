def run(args):
    if args:
        print(" ".join(args))
